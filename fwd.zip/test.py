import config

print config.basedir
