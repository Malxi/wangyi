from flask_mail import Message
from flask import render_template
from app import config, mail


def send_email(to, subject, template, **kw):
    msg = Message('Welcome' + subject, sender='13987610292@sina.cn', recipients=[to])
    msg.body = render_template(template + '.txt',**kw)
    msg.html = render_template(template + '.html', **kw)
    mail.send(msg)

